package com.example.techwintask

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class ItemAdapter(val dataList: ArrayList<DataModel>, val context: Context): RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    class ViewHolder(ItemView: View): RecyclerView.ViewHolder(ItemView){

        val countryName:TextView = ItemView.findViewById(R.id.country_name)
        val countryCode:TextView = ItemView.findViewById(R.id.country_code)
        val countryImage:ImageView = ItemView.findViewById(R.id.country_Image)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_file,parent,false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val model = dataList.get(position)
        holder.countryName.text = model.country_name
        holder.countryCode.text = model.country_code

        Picasso.get().load(model.country_image).into(holder.countryImage);

    }
}