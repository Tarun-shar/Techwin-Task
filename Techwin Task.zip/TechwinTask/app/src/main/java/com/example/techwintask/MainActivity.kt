package com.example.techwintask

import com.android.volley.Request
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.techwintask.databinding.ActivityMainBinding
import org.json.JSONObject

class MainActivity : AppCompatActivity() {

    lateinit var adapterObj : ItemAdapter
    lateinit var dataList : ArrayList<DataModel>

    private val url = "https://bpj.scf.mybluehost.me/mylocalbusiness/getCountries"

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dataList = ArrayList()
        getData()
    }

    private fun getData() {
        val queue = Volley.newRequestQueue(this)

        val stringRequest = StringRequest(Request.Method.GET, url,
            { response ->

                val responseObject = JSONObject(response)

                val responseArrayObj = responseObject.getJSONArray("data")
                for (i in 0 until responseArrayObj.length()){
                    val responseObj2 = responseArrayObj.getJSONObject(i)

                    val country_name = responseObj2.get("countries_name").toString()
                    val country_code = responseObj2.get("country_code").toString()
                    val countryImage = responseObj2.get("flag").toString()
//
                    dataList.add(DataModel(countryImage , country_name, country_code))
//
                    adapterObj = ItemAdapter(dataList,this)
                    binding.recyclerView.layoutManager = LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false)
                    binding.recyclerView.adapter = adapterObj

                }

            },
            {error ->
                Toast.makeText(this, error.localizedMessage, Toast.LENGTH_SHORT).show()
            })

// Add the request to the RequestQueue.
        queue.add(stringRequest)
    }
}