package com.example.techwintask

data class DataModel(val country_image: String, val country_name: String, val country_code: String)
